<?php
@session_start ();
require_once ("classes/Database.php");
require_once ("classes/User.php");
require_once ("classes/Enteries.php");
$user= new User ();